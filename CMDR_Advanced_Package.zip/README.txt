
CMDR Advanced Package
=====================

В этом пакете команды:
- /setweather crabrave — спавнит крабов + музыку Crab Rave + таймер и картинку на 1 минуту
- /setweather disco — спавнит диджейский стол + музыку + таймер и картинку на 1 минуту
- /kick <Player> — кикает игрока
- /ban <Player> — банит игрока и блокирует повторный вход (сохранение навсегда)
- /teleport <Player1> <Player2> — телепортирует первого игрока ко второму

Установка:
1. Импортируйте .rbxm модель в Roblox Studio.
2. Перетащите Script в ServerScriptService, LocalScript в StarterGui, модели в ReplicatedStorage.
3. В Script укажите UserId админов в таблице ADMINS.
4. Для банов DataStoreService должен быть включен (Studio -> Home -> Game Settings -> Security -> Enable Studio API Access to DataStores).
