
-- CMDR Advanced Server Script (примерный код)
-- Таблица админов
local ADMINS = {12345678, 87654321}

-- Здесь идут реализации команд /kick, /ban, /teleport, /setweather crabrave, /setweather disco
-- Код опущен для примера
